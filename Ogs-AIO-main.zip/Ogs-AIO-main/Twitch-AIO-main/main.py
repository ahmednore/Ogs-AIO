import httpx, json, threading, random, ctypes, socks, time, os; from itertools import cycle

class bcolors:
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

class ReturnToken:
    def get_token():
        with open('Data/tokens.txt', 'r') as temp_file:
            tokens = [line.rstrip('\n') for line in temp_file]
        return tokens
    token = get_token()
    token_pool = cycle(token)

class Twitch:
    def __init__(self):
        self.set_title()
        self.logo()
        self.base_headers = { 

        'Connection': 'keep-alive',
        'access-control-allow-headers': 'X-Device-ID',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'Accept-Language': 'en-US',
        'sec-ch-ua-mobile': '?0',
        'Client-Version': 'eec61afe-c58c-4c74-8c88-5818156a2b22',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36',
        'Content-Type': 'text/plain;charset=UTF-8',
        'Client-Session-Id': '51789c1a5bf92c65',
        'Client-Id': 'kimne78kx3ncx6brgo4mv6wki5h1ko',
        'X-Device-Id': 'aSZWsu5RGHJDLDRBtiN2TujM0atTPK1d',
        'sec-ch-ua-platform': '"Windows"',
        'Accept': '*/*',
        'Origin': 'https://www.twitch.tv',
        'Sec-Fetch-Site': 'same-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://www.twitch.tv/',
        'Accept-Encoding': 'gzip, deflate, br',

        } 

        with open('config.json', 'r') as f:
            self.config = json.load(f)


        self.valid=0
        self.invalid=0
        self.bio_changed=0

        self.reported=0

        self.followed=0
        self.unfollowed=0
        self.failed=0

        self.sent=0
        self.joined=0

    def set_title(self):
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^|Tokens Loaded: {len(open('Data/tokens.txt', 'r').readlines())} ^|Proxies: {len(open('Data/proxies.txt', 'r').read().splitlines())}")


    def clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def logo(self):
        logo=f"""
{bcolors.RESET} /$$$$$$                             /$$$$$$  /$$$$$$  /$$$$$$ {bcolors.RESET}
{bcolors.RESET} /$$__  $$                           /$$__  $$|_  $$_/ /$$__  $${bcolors.RESET}
{bcolors.RESET}| $$  \ $$  /$$$$$$   /$$$$$$$      | $$  \ $$  | $$  | $$  \ $${bcolors.RESET}
{bcolors.RESET}| $$  | $$ /$$__  $$ /$$_____/      | $$$$$$$$  | $$  | $$  | $${bcolors.RESET}
{bcolors.RESET}| $$  | $$| $$  \ $$|  $$$$$$       | $$__  $$  | $$  | $$  | $${bcolors.RESET}
{bcolors.RESET}| $$  | $$| $$  | $$ \____  $$      | $$  | $$  | $$  | $$  | $${bcolors.RESET}
{bcolors.RESET}|  $$$$$$/|  $$$$$$$ /$$$$$$$/      | $$  | $$ /$$$$$$|  $$$$$$/{bcolors.RESET}
{bcolors.RESET} \______/  \____  $$|_______/       |__/  |__/|______/ \______/ {bcolors.RESET}
{bcolors.RESET}           /$$  \ $$                                           {bcolors.RESET} 
 {bcolors.RESET}         |  $$$$$$/                                         {bcolors.RESET}   
 {bcolors.RESET}          \______/                                             {bcolors.RESET}
                                                                   
    """
        print(logo)


    def get_id(self, name:str):
        proxy=open('Data/proxies.txt', "r").read().splitlines()
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        self.res = client.post('https://gql.twitch.tv/gql', timeout=3,headers=self.base_headers, data='[{"operationName": "WatchTrackQuery","variables": {"channelLogin": "'+name+'","videoID": null,"hasVideoID": false},"extensions": {"persistedQuery": {"version": 1,"sha256Hash": "38bbbbd9ae2e0150f335e208b05cf09978e542b464a78c2d4952673cd02ea42b"}}}]')
        if self.res.json()[0]["data"]["user"]==None:
            print('[-] Invalid Username')
            time.sleep(3)
            self.main()
        else:
           return self.res.json()[0]['data']['user']['id']
        



    def check(self, valid:list):
        token=next(ReturnToken.token_pool)
        proxy=open('Data/proxies.txt', "r").read().splitlines()
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        client.headers["Authorization"] = f"OAuth {token}"
        self.res=client.post("https://gql.twitch.tv/gql", json = [{"operationName":"BitsCard_Bits","variables":{},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"fe1052e19ce99f10b5bd9ab63c5de15405ce87a1644527498f0fc1aadeff89f2"}}},{"operationName":"BitsCard_MainCard","variables":{"name":"679087745","withCheerBombEventEnabled":False},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"88cb043070400a165104f9ce491f02f26c0b571a23b1abc03ef54025f6437848"}}}])
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Valid: {self.valid} ^| Invalid: {self.invalid} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        if "token is invalid." in self.res.text:
            print(f"[!] {bcolors.RED}Token is invalid: {token}{bcolors.RESET}")
            self.invalid+=1
        else:
            print(f"[!] {bcolors.GREEN}Token is valid: {token}{bcolors.RESET}")
            self.valid+=1
            valid.append(token)


    def follow_bot(self, channel):
        token=next(ReturnToken.token_pool)
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        client.headers["Authorization"] = f"OAuth {token}"
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Followed: {self.followed} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        self.res=client.post(f'https://gql.twitch.tv/gql', json=[{"operationName":"AvailableEmotesForChannel","variables":{"channelID":channel,"withOwner":True},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"b9ce64d02e26c6fe9adbfb3991284224498b295542f9c5a51eacd3610e659cfb"}}},{"operationName":"FollowButton_FollowUser","variables":{"input":{"disableNotifications":False,"targetID":channel}},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"800e7346bdf7e5278a3c1d3f21b2b56e2639928f86815677a7126b093b2fdd08"}}}])
        if self.res.status_code in [204, 200]:
            print(f"[!] {bcolors.GREEN}Followed with: {token}{bcolors.RESET}")
            self.followed+=1
        else:
            print(f"[!] {bcolors.RED}Failed with: {token}{bcolors.RESET}")
            self.failed+=1

    #def change_pfp(self):

    def unfollow_bot(self, channel):
        token=next(ReturnToken.token_pool)
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies=f'http://'+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        client.headers["Authorization"] = f"OAuth {token}"
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Unfollowed: {self.unfollowed} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        self.res=client.post(f'https://gql.twitch.tv/gql', json=[{"operationName":"AvailableEmotesForChannel","variables":{"channelID":channel,"withOwner":True},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"b9ce64d02e26c6fe9adbfb3991284224498b295542f9c5a51eacd3610e659cfb"}}},{"operationName":"FollowButton_UnfollowUser","variables":{"input":{"targetID":channel}},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"f7dae976ebf41c755ae2d758546bfd176b4eeb856656098bb40e0a672ca0d880"}}}])
        if self.res.status_code in [204, 200]:
            print(f"[!] {bcolors.GREEN}Unfollowed with: {token}{bcolors.RESET}")
            self.unfollowed+=1
        else:
            print(f"[!] {bcolors.RED}Failed with: {token}{bcolors.RESET}")
            self.failed+=1



    def chat_spam(self, channel_name, message, channel):
        while True:
            try:
               token=next(ReturnToken.token_pool)
               proxies=random.choice(open('Data/proxies.txt', "r").read().splitlines())
               client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+proxies)
               client.headers["Authorization"] = f"OAuth {token}"
               proxy = proxies.split(":")
               client.post(f'https://gql.twitch.tv/gql', json='[{\"operationName\":\"FollowButton_FollowUser\",\"variables\":{\"input\":{\"disableNotifications\":false,\"targetID\":\"'+channel+'\"}},\"extensions\":{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"51956f0c469f54e60211ea4e6a34b597d45c1c37b9664d4b62096a1ac03be9e6\"}}}]')
               self.res=client.get('https://id.twitch.tv/oauth2/validate')
               ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Sent: {self.sent} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
               token_name=self.res.json()["login"]
               s = socks.socksocket()
               s.set_proxy(socks.HTTP, proxy[0],int(proxy[1]))
               s.connect(("irc.chat.twitch.tv", 6667))
               s.send("CAP REQ :twitch.tv/tags twitch.tv/commands\r\n".encode("utf8"))
               s.send(f"PASS oauth:{token}\r\n".encode("utf8"))
               s.send(f"NICK {token_name}\r\n".encode("utf8"))
               s.send(f"JOIN #{channel_name}\r\n".encode("utf8"))
               s.send(f"PRIVMSG #{channel_name} :{message}\r\n".encode("utf8"))
               s.close()
               self.sent+=1
            except Exception as e:
                print('[ERROR] >', e)
                self.failed+=1
                pass


    def raid_bot(self, raid_id):
        token = next(ReturnToken.token_pool)
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        client.headers["Authorization"] = f"OAuth {token}"
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Sent: {self.joined} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        self.res=client.post(f'https://gql.twitch.tv/gql', data='[{"operationName":"JoinRaid","variables":{"input":{"raidID":"'+raid_id+'"}},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"c6a332a86d1087fbbb1a8623aa01bd1313d2386e7c63be60fdb2d1901f01a4ae"}}}]')
        if self.res.status_code in [204, 200]:
            print(f"[!] {bcolors.GREEN}Joined with: {token}{bcolors.RESET}")
            self.joined+=1
        else:
            print(f"[!] {bcolors.RED}Failed with: {token}{bcolors.RESET}")
            self.failed+=1



    def Live_viewbot(self):
        print('[!] Live Viewbot is not yet implemented.')


    def bio_changer(self, bio:str):
        token=next(ReturnToken.token_pool)
        if self.config['use_proxy']:
            proxy=open('Data/proxies.txt', "r").read().splitlines()
            client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        else:
            client = httpx.Client(timeout=3,headers=self.base_headers)
        client.headers["Authorization"] = f"OAuth {token}"
        res=client.get('https://id.twitch.tv/oauth2/validate')
        token_name=res.json()["login"]
        userid=res.json()["user_id"]
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Changed: {self.bio_changed} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        bio_req = client.post(
                        url = "https://gql.twitch.tv/gql", 
                        headers = {
                            "Authorization": f"OAuth {token}",
                        }, 
                        json = [
                            {
                                "operationName": "UpdateUserProfile",
                                "variables": {
                                    "input": 
                                        {
                                            "displayName": token_name, 
                                            "description":f'{bio}',
                                            "userID": userid
                                            }
                                        },
                                "extensions": 
                                    {
                                        "persistedQuery": 
                                            {
                                                "version": 1,
                                                "sha256Hash": "991718a69ef28e681c33f7e1b26cf4a33a2a100d0c7cf26fbff4e2c0a26d15f2"
                                                }
                                            }
                                    }
                        ]
                    )
        if bio_req.status_code in [204,200]:
            print(f"[!] {bcolors.GREEN}Bio changed with: {token} | Name: {token_name}{bcolors.RESET}")
            self.bio_changed+=1
        else:
            print(f"[!] {bcolors.RED}Failed with: {token} | Name: {token_name}{bcolors.RESET}")
            self.failed+=1 


    def report(self, channel, report_reason):
        token=next(ReturnToken.token_pool)
        proxy=open('Data/proxies.txt', "r").read().splitlines()
        client = httpx.Client(timeout=3,headers=self.base_headers, proxies="http://"+random.choice(proxy))
        client.headers["Authorization"] = f"OAuth {token}"
        ctypes.windll.kernel32.SetConsoleTitleW(f"[TwitchAIO] - ^| Reported: {self.reported} ^| Failed: {self.failed} ^| Tokens: {len(open('Data/tokens.txt', 'r').read().splitlines())}")
        self.res=client.post(f'https://gql.twitch.tv/gql', json=[{"operationName":"ReportWizard_CreateReport","variables":{"input":{"content":"USER_REPORT","description":f"{report_reason}","detailedReason":"scam","reason":"spam","targetUserID":channel,"sessionID":"6631b2e97e021e793b1eaa917e7cef50"}},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"fbbc2da2ea493e98f6ee102068d7a4eba3b20e2766195df854903a893a1b1cbe"}}}])
        if self.res.status_code in [200,201,204]:
            print(f"[TwitchAIO] - Reported With: {token}")
            self.reported+1
        else:
            print(f"[TwitchAIO] - Failed To Report With: {token}")
            self.failed+=1
            pass
    
    def main(self):
        self.clear()
        self.logo()
        self.set_title()
        print('')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}1{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Token Generator{bcolors.RESET}')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}2{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Follow Bot{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}3{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Unfollow Bot{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}4{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Raid Bot{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}5{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Check Tokens{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}6{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Chat Spammer{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}7{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Report Bot{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}8{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Live Viewbot{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}9{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}Bio Changer{bcolors.RESET} ')
        print(f'                    {bcolors.RED}[{bcolors.CYAN}10{bcolors.RESET}{bcolors.RED}]{bcolors.RESET} {bcolors.CYAN}PFP Changer{bcolors.RESET}')
        print('')
        print('')
        options=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Select an option > {bcolors.RESET}')
        if options=='1':
            print('Buy at discord.gg/clipssender lol')


        elif options=='2':
            channel_id=self.get_id(input(f'{bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Input Channel Name > {bcolors.RESET}'))
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.follow_bot, args=(channel_id,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            time.sleep(3)
            self.main()


        elif options=='3':
            channel=self.get_id(input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Input Channel Name > {bcolors.RESET}'))
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.unfollow_bot, args=(channel,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            time.sleep(3)
            self.main()


        elif options=='4':
            raid_id=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Input Raid ID > {bcolors.RESET}')
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.raid_bot, args=(raid_id,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            time.sleep(3)
            self.main()


        elif options=='5':
            validtokens=[]
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.check, args=(validtokens,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            open('Data/tokens.txt', 'w').write('')
            for validtoken in validtokens:
                open('Data/tokens.txt', 'a').write(f'{validtoken}\n')
            time.sleep(3)
            self.main()


        elif options=='6':
            channel_name=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Enter the name of the channel > {bcolors.RESET}')
            message=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Enter message to spam > {bcolors.RESET}')
            channel_id=self.get_id(channel_name)
            while True:
                for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                    threading.Thread(target=self.chat_spam, args=(channel_name, message, channel_id,)).start()


        elif options=='7':
            channel_id=self.get_id(input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Enter the name of the channel > {bcolors.RESET}'))
            report_reason=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Enter the reason for the report > {bcolors.RESET}')
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.report, args=(channel_id, report_reason,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            time.sleep(3)
            self.main()


        elif options=='8':
            print('Live viewbot has not been implemented yet | discord.gg/clipssender on top')
            time.sleep(3)
            self.main()


        elif options=='9':
            bio=input(f'  {bcolors.GREEN}[ {bcolors.CYAN}?{bcolors.RESET}{bcolors.GREEN} ] - Enter the new bio > {bcolors.RESET}')
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t=threading.Thread(target=self.bio_changer, args=(bio,))
                t.start()
            for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
                t.join()
            time.sleep(3)
            self.main()


        elif options=='10':
            #input(f'  {bcolors.GREEN}[ {bcolors.CYAN}!{bcolors.RESET}{bcolors.GREEN} ] - Press Enter to Continue. Ensure you have put Profiles Pictures in the ./avatars/ directory > {bcolors.RESET}')
            #for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
            #    t=threading.Thread(target=self.change_pfp)
            #    t.start()
            #for i in range(len(open('Data/tokens.txt', 'r').read().splitlines())):
            #    t.join()
            #time.sleep(3)
            #self.main()
            print('not implemented yet')
            time.sleep(3)
            self.main()

            
        else:
            print(f'{bcolors.RED}Invalid Option')
            time.sleep(3)
            self.main()
        


if __name__=="__main__":
    try:
        Twitch().main()
    except KeyboardInterrupt:
        exit()
